# Python Debugger (pdb + debugpy)

## Tool Selection

| Tool | When |
|---|---|
| **`breakpoint()` + pdb** | Local, interactive, simplest |
| **`python -m pdb`** | Launch existing script under pdb, no source edits |
| **`debugpy`** | Remote / headless / attach to running process (DAP) |

**Start with `breakpoint()`.** It's the cheapest thing that works.

## pdb Quick Reference

| Command | Action |
|---|---|
| `n` / `s` / `r` / `c` | next / step into / return / continue |
| `unt N` | continue until line N |
| `w` | where (stack trace) |
| `p expr` / `pp expr` | print / pretty-print |
| `interact` | drop into full Python REPL in current scope |
| `b file:line` / `b func` | set breakpoint |
| `!stmt` | execute arbitrary Python |
| `q` | quit |

## Key Recipes

### Local breakpoint
```python
def compute(x, y):
    breakpoint()  # drops into pdb here
    return x + y
```
**Always remove `breakpoint()` before committing:** `rg -n 'breakpoint\(\)' --type py`

### Debug pytest
```bash
# Drop to pdb on failure (MUST disable xdist):
pytest tests/foo_test.py::test_bar --pdb -p no:xdist
```

### Post-mortem
```python
import pdb, sys
try:
    run_the_thing()
except Exception:
    pdb.post_mortem(sys.exc_info()[2])
```

### Remote debug with debugpy
```python
import debugpy
debugpy.listen(("127.0.0.1", 5678))
debugpy.wait_for_client()
debugpy.breakpoint()
```

Or launch without source edit:
```bash
python -m debugpy --listen 127.0.0.1:5678 --wait-for-client your_script.py
```

### Attach to running process
```bash
python -m debugpy --listen 127.0.0.1:5678 --pid <pid>
```

### remote-pdb (terminal-friendly)
```python
from remote_pdb import set_trace
set_trace(host="127.0.0.1", port=4444)
```
Then: `nc 127.0.0.1 4444` — get a (Pdb) prompt.

## Hermes-Specific Debugging

### Tests
Always add `-p no:xdist`. `scripts/run_tests.sh` uses xdist by default.

### `tui_gateway` subprocess
Source-edit gateway: add `debugpy.listen/wait_for_client` near top of `serve()`.
Or use `remote-pdb` at specific handler, trigger from TUI, then `nc` to connect.

### `_SlashWorker` subprocess
Same pattern — `remote-pdb` with `set_trace()` inside worker's `exec` path.

### Gateway (`gateway/run.py`)
Long-lived. Use `remote-pdb` at handler, or `debugpy --wait-for-client` if restarting.

## Common Pitfalls

1. **pdb under pytest-xdist silently does nothing** — always `-p no:xdist`
2. **`breakpoint()` in CI/non-TTY hangs** — safe locally, never commit
3. **`PYTHONBREAKPOINT=0`** disables all `breakpoint()` calls
4. **`debugpy.listen` blocks only with `wait_for_client()`**
5. **Attach to PID fails on hardened kernels** — `ptrace_scope=1` blocks ptrace
6. **pdb only debugs current thread** — use debugpy for multithreaded
7. **asyncio await inside pdb requires Python 3.13+** — use `interact` mode on older
8. **`scripts/run_tests.sh` strips credentials** — debug with raw pytest first
9. **pdb does not follow forks** — each child needs own breakpoint

## Cleanup
```bash
rg -n 'breakpoint\(\)|set_trace\(|debugpy\.listen' --type py
```
