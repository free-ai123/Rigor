# Node.js Debugger (--inspect + CDP)

## Tool Selection

- **`node inspect`** — built-in CLI REPL, zero install. Best for quick poking.
- **`--inspect-brk` + CDP** — scriptable from terminal. Best for automation.

**Prefer `node inspect` first.**

## Quick Reference: `node inspect` REPL

```bash
node inspect path/to/script.js
# or with tsx:
node --inspect-brk $(which tsx) path/to/script.ts
```

| Command | Action |
|---|---|
| `c` / `n` / `s` / `o` | continue / next / step in / step out |
| `sb('file.js', 42)` | set breakpoint |
| `bt` | backtrace |
| `repl` | drop into REPL in current scope (Ctrl+C to exit) |
| `exec expr` | evaluate expression |

## Attaching to Running Process

```bash
kill -SIGUSR1 <pid>   # enables inspector on ws://127.0.0.1:9229/<uuid>
node inspect -p <pid>
```

Or start with inspector:
```bash
node --inspect script.js           # listen, keep running
node --inspect-brk script.js       # listen AND pause on first line
```

## Hermes ui-tui Debugging

```bash
hermes --tui &
TUI_PID=$(pgrep -f 'ui-tui/dist/entry' | head -1)
kill -SIGUSR1 "$TUI_PID"
node inspect ws://127.0.0.1:9229/<uuid>
```

## Vitest Under Debugger

```bash
cd ui-tui
node --inspect-brk ./node_modules/vitest/vitest.mjs run --no-file-parallelism src/app/foo.test.tsx
```

## Common Pitfalls

1. **Wrong line numbers in TS** — breakpoints hit emitted JS. Break in `dist/*.js` or enable sourcemaps.
2. **`--inspect` vs `--inspect-brk`** — use `-brk` when you need to set breakpoints before code runs.
3. **Port collisions** — default is 9229. Use `--inspect=0` for random port.
4. **Child processes** — `--inspect` on parent does NOT inspect children. Use `NODE_OPTIONS='--inspect-brk'`.
5. **Security** — `--inspect=0.0.0.0:9229` exposes arbitrary code execution. Always bind to 127.0.0.1.
