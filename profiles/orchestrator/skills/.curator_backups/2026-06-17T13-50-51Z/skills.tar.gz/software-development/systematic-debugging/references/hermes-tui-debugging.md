# Debugging Hermes TUI Slash Commands

## Architecture

```
Python backend (hermes_cli/commands.py)     <- canonical COMMAND_REGISTRY
       │
       ▼
TUI gateway (tui_gateway/server.py)         <- slash.exec / command.dispatch
       │
       ▼
TUI frontend (ui-tui/src/app/slash/)        <- local handlers + fallthrough
```

Command definitions must be registered consistently across Python and TypeScript.
The Python `COMMAND_REGISTRY` is the source of truth.

## Investigation Steps

1. Check TUI frontend: `search_files --pattern "/commandname" --file_glob "*.ts" --path ui-tui/`
2. Examine TUI definition: `read_file ui-tui/src/app/slash/commands/core.ts`
3. Check Python backend: `search_files --pattern "commandname" --path hermes_cli/commands.py`
4. Examine gateway: `search_files --pattern "complete.slash|slash.exec" --path tui_gateway/`

## Common Issues

1. **Command shows in TUI but not autocomplete** — missing from `COMMAND_REGISTRY` in `hermes_cli/commands.py`. Autocomplete data ships from Python.
2. **Command shows in autocomplete but doesn't work** — check handler in `tui_gateway/server.py` and frontend handler.
3. **Behavior differs between CLI and TUI** — different implementations. Check both `cli.py::process_command` and TUI's local handler.
4. **Persists config but doesn't apply live** — must also patch nanostore state (`patchUiState(...)`) and thread through all render paths.
5. **Gateway dispatch silently ignores** — check `GATEWAY_KNOWN_COMMANDS` includes the canonical name.

## Fix: Missing Command Autocomplete

Add to `COMMAND_REGISTRY` in `hermes_cli/commands.py`:
```python
CommandDef("commandname", "Description", "Session",
           cli_only=True, aliases=("alias",),
           args_hint="[arg1|arg2|arg3]",
           subcommands=("arg1", "arg2", "arg3")),
```

- `cli_only=True` — only in interactive CLI/TUI
- `gateway_only=True` — only in messaging platforms
- `gateway_config_gate="display.foo"` — config-gated availability

## Verification

1. Rebuild TUI: `npm --prefix ui-tui run build`
2. Run TUI, type `/` to verify autocomplete
3. Execute command, confirm behavior + config updates
4. If gateway-available, test from messaging platform
