---
name: nodejs-collector-pattern
description: "Node.js multi-chain collector service reference: 38-file structure, 15-table schema, env-based config (12 sections), Feishu alerting, health checks. ETH/BSC/TRON auto-collection with AES-256-GCM key encryption."
version: 2.0.0
platforms: [linux, macos]
metadata:
  hermes:
    tags: [nodejs, crypto, multi-chain, collector, mysql]
---

# Node.js Multi-Chain Collector Service — Reference Pattern

## Core Architecture

Single-process Node.js service with 6 cron jobs + health check job, MySQL task queue, dual databases (biz read-only + collector read-write). All configurable parameters in `.env` organized by chain and functional section (12 sections, ~78 vars).

## Required Files (38 JS files)

```
collector-service/
├── app.js                          # Entry: init DB pools, start 7 jobs, handle SIGTERM/SIGINT
├── config/
│   ├── index.js                    # Re-exports: db config, CHAIN_MAP, envConfig
│   └── envConfig.js                # Unified config from .env: per-chain params, jobSchedule,
│                                   #   batchSize, lockAndRetry, rpcLimit, gasLimits, alert
├── db/
│   ├── index.js                    # Re-export both pools + closePools()
│   ├── collectorDb.js              # initCollectorPool / getCollectorPool / closeCollectorPool
│   └── bizDb.js                    # initBizPool / getBizPool / closeBizPool
├── adapters/
│   ├── evmAdapter.js               # ethers.js v6: balance, token, send, receipt, blockNumber
│   └── tronAdapter.js              # tronweb: same interface + feeLimit
├── services/
│   ├── collectTaskService.js       # Create tasks, update status, lock/unlock (MySQL locks)
│   ├── collectService.js           # Execute collection: decrypt key, build+sign+send tx
│   ├── feeService.js               # Top up fee wallet → user address (reads feeWalletPrivateKey from .env)
│   ├── balanceService.js           # Scan main + token balance, update address_balance
│   ├── addressSyncService.js       # Sync biz DB status=1 addresses → wallet_address
│   ├── monitorService.js           # Check tx receipts, confirmations, pending timeout
│   ├── nonceService.js             # EVM nonce: SELECT FOR UPDATE, max(local, chain_pending)
│   ├── gasService.js               # Gas from .env: EIP-1559 (ETH), gasPrice (BSC)
│   ├── rpcService.js               # RPC pool: priority selection, Bottleneck rate limit
│   ├── walletGenerateService.js    # Generate EVM/TRON wallets, encrypt + save
│   ├── alertService.js             # Write to system_alert + send Feishu webhook card
│   ├── feishuAlert.js              # Feishu interactive card builder + HTTP POST + cooldown
│   ├── healthService.js            # 7-dim health check: DB/RPC/balance/backlog/fail/pending/alerts
│   └── taskLogService.js           # Write to task_status_log
├── jobs/
│   ├── index.js                    # Re-export all jobs
│   ├── addressSyncJob.js           # Sync biz DB → wallet_address (every 15s)
│   ├── balanceScanJob.js           # Scan balances, create tasks at threshold (every 60s)
│   ├── collectJob.js               # Execute MAIN_COLLECT and TOKEN_COLLECT (every 10s)
│   ├── feeJob.js                   # Top up insufficient fee (every 10s)
│   ├── monitorJob.js               # Check tx confirmations, handle timeouts (every 15s)
│   ├── retryJob.js                 # Retry failed tasks, exponential backoff (every 30s)
│   └── healthCheckJob.js           # 7-dim health check, auto-alert on critical (every 5min)
├── utils/
│   ├── crypto.js                   # AES-256-GCM: encryptPrivateKey / decryptPrivateKey
│   ├── amount.js                   # toWei/fromWei (decimal.js), aliases: toRaw/fromRaw
│   └── logger.js                   # winston: 4 log files, redact private keys/0x64hex
├── constants/
│   └── status.js                   # TASK_PENDING=0..TASK_SKIPPED=8, TX_STATUS, WALLET_STATUS
├── scripts/
│   ├── check_status.js             # Manual: show task stats, alerts, pending, RPC, recent tx
│   └── test_all.js                 # Full end-to-end verification (env, DB, crypto, amount, alert)
├── package.json                    # ethers tronweb mysql2 decimal.js dotenv winston node-cron uuid bottleneck
├── .env                            # 12 categorized sections, ~78 config vars (see below)
├── .gitignore                      # node_modules, .env, logs/
└── README.md
```

## .env Configuration (12 Sections)

```ini
# [1] 基础环境     NODE_ENV, WORKER_ID, LOG_LEVEL
# [2] 数据库配置   BIZ_DB_*, COLLECTOR_DB_* (host/port/user/password/name/poolSize)
# [3] 私钥加密     WALLET_MASTER_KEY (64-char hex, 32 bytes)
# [4] ETH 主网     ETH_COLLECT_ADDRESS, ETH_FEE_WALLET_PRIVATE_KEY
#                  ETH_RPC_URL, ETH_RPC_URL_2
#                  ETH_MAX_FEE_PER_GAS, ETH_MAX_PRIORITY_FEE
#                  ETH_MIN_COLLECT, ETH_USDT_MIN_COLLECT
#                  ETH_MIN_FEE_BALANCE, ETH_FEE_TOPUP_AMOUNT, ETH_RESERVE_MAIN
#                  ETH_CONFIRM_BLOCKS, ETH_TX_TIMEOUT
# [5] BSC 链       (same as ETH, with BSC_MAX_GAS_PRICE instead of EIP-1559)
# [6] TRON 链      (same as ETH, with TRON_FEE_LIMIT instead of gas)
# [7] 公共Gas限制  MAIN_TRANSFER_GAS_LIMIT(21000), TOKEN_TRANSFER_GAS_LIMIT(80000), FEE_TOPUP_GAS_LIMIT(65000)
# [8] 定时任务     JOB_ADDRESS_SYNC_INTERVAL(15), JOB_BALANCE_SCAN_INTERVAL(60),
#                  JOB_COLLECT_INTERVAL(10), JOB_FEE_INTERVAL(10),
#                  JOB_MONITOR_INTERVAL(15), JOB_RETRY_INTERVAL(30)
# [9] 批处理大小   BATCH_ADDRESS_SYNC(500), BATCH_COLLECT(10), BATCH_FEE(10),
#                  BATCH_MONITOR(50), BATCH_RETRY(20),
#                  BATCH_SCAN_ETH(100), BATCH_SCAN_BSC(200), BATCH_SCAN_TRON(100)
# [10] 锁与重试    TASK_LOCK_TTL(60), MAX_RETRY(5), RETRY_INTERVALS(60,300,900,3600)
# [11] RPC限流     RPC_MAX_CONCURRENT(5), RPC_MIN_TIME_MS(150)
# [12] 告警        ALERT_WEBHOOK_URL, ALERT_THRESHOLD_RPC_FAIL(3), ALERT_COOLDOWN_SECONDS(300)
```

**config/envConfig.js** exports:
- `getChainConfig(chain)` — per-chain object: collectAddress, feeWalletPrivateKey, rpcUrls[], minCollectMain, minCollectUsdt, minFeeBalance, feeTopupAmount, reserveMain, confirmBlocks, txTimeout, gas params
- `getUsdtContract(chain)` / `getUsdtDecimals(chain)` — hardcoded USDT contract addresses
- `jobSchedule`, `batchSize`, `lockAndRetry`, `rpcLimit`, `gasLimits`, `alert` — grouped config
- `ETH`, `BSC`, `TRON` — pre-built chain config objects

## Database Tables (15 in collector DB)

wallet_key (chain, address, private_key_cipher/iv/tag),
wallet_address (biz_address_id, chain, address, wallet_key_id, status, last_scan_time),
chain_config (chain, chain_type, main_symbol, chain_id, confirm_blocks),
asset_config (chain, symbol, asset_type, contract_address, decimals, collect_address, thresholds),
fee_wallet (chain, address, private_key_cipher/iv/tag, balance_cache),
address_balance (wallet_address_id, chain, symbol, balance, raw_balance),
collect_task (task_no, task_type, from_address, to_address, amount, status 0-8, fee/collect_tx_hash, locked_by/until),
collect_task_open (task_key UNIQUE, task_id — idempotency),
chain_transaction (task_id, tx_hash, nonce, block_number, gas params, status 0-4, expire_at),
nonce_state (chain, address, next_nonce, pending_count, locked_by/until),
gas_policy (chain, mode, gas params),
rpc_endpoint (chain, url, priority, status, fail_count),
task_status_log (task_id, old_status, new_status, reason),
system_alert (level, type, chain, address, task_id, message, status),
collector_state (state_key, state_value)

## Key Patterns

1. **Task locking**: `UPDATE collect_task SET locked_by=?, locked_until=? WHERE id=? AND status IN (0,3) AND (locked_until IS NULL OR locked_until < UNIX_TIMESTAMP())`
2. **Nonce allocation**: Transaction + `SELECT FOR UPDATE` on nonce_state, `max(local_next_nonce, chain_pending_nonce)`
3. **Idempotency**: `collect_task_open` with `UNIQUE(task_key)` where task_key = `chain:symbol:from_address`
4. **RPC failover**: Query rpc_endpoint ordered by priority ASC, skip status=2 (unhealthy), increment fail_count on error
5. **Pending timeout**: Set `expire_at = now + timeout` on broadcast; `UPDATE SET status=4 WHERE expire_at < NOW()`
6. **Amount precision**: Always store both `amount` (DECIMAL) and `raw_amount` (VARCHAR wei/sun)
7. **AES-256-GCM**: Store cipher (TEXT hex) + iv (VARCHAR 12-byte hex) + tag (VARCHAR 16-byte hex) separately
8. **Fee check before token collection**: Compare main coin balance against minFeeBalance from .env; set task status=1 (need fee) if insufficient
9. **Config-driven**: All thresholds, gas params, confirm blocks, timeouts read from .env via envConfig — zero hardcoded values in jobs/services
10. **Feishu alert**: alertService.createAlert() writes to DB + sends Feishu webhook card (async, with 300s cooldown per alert type)
11. **Health check**: 7 dimensions checked every 5min — DB connectivity, RPC availability, fee wallet balance, task backlog (>50 stuck), failed tasks (>5/hour), pending tx (>20), unresolved alerts

## Monitoring Queries

```sql
-- Quick health check
SELECT
  (SELECT COUNT(*) FROM system_alert WHERE status=0 AND level='CRITICAL') as critical,
  (SELECT COUNT(*) FROM collect_task WHERE status=7 AND updated_at > UNIX_TIMESTAMP()-3600) as failed_1h,
  (SELECT COUNT(*) FROM chain_transaction WHERE status=1) as pending_txs,
  (SELECT COUNT(*) FROM collect_task WHERE status IN (0,3) AND created_at < UNIX_TIMESTAMP()-300) as stuck_tasks;

-- Task backlog by chain
SELECT chain, symbol, status, COUNT(*) as cnt
FROM collect_task GROUP BY chain, symbol, status;

-- Pending transactions with timeout remaining
SELECT chain, tx_hash, expire_at - UNIX_TIMESTAMP() as seconds_left
FROM chain_transaction WHERE status=1 ORDER BY expire_at ASC;
```

## Deployment

```bash
cd /root/projects/collector-service/collector-service
npm install
# Edit .env: fill in COLLECT_ADDRESS, FEE_WALLET_PRIVATE_KEY, RPC URLs
pm2 start app.js --name collector-service
pm2 logs collector-service
```

## Pitfalls

- **Worker schema drift**: Backend workers may modify DB field names from the spec. Always verify table structure with `DESCRIBE` after DB tasks complete.
- **Worker code interface drift**: Workers also change function exports, module names, and constant values (not just DB schemas). Examples seen: `crypto.js` exported `encrypt`/`decrypt` instead of `encryptPrivateKey`/`decryptPrivateKey`; `amount.js` had `toWei`/`fromWei` but missing `toRaw`/`fromRaw` aliases; `db/collectorDb.js` lacked `initCollectorPool`/`getCollectorPool`; `constants/status.js` had values 1-5 instead of DB-expected 0-8. After code tasks complete, run `node -e "Object.keys(require('./module'))"` to verify expected exports exist.
- **MySQL password reset**: Devops tasks may reset root password. If `mysql -uroot -p<old>` fails, use skip-grant-tables mode to reset.
- **Terminal blocks**: Workers with blocked terminal access cannot install npm deps or verify DB connections. Write files directly to persistent project directory.
- **Scratch workspace GC**: Each worker's files are deleted on task completion. Copy to `~/projects/<name>/` immediately after each task completes.
