# Orchestrator CLI Pitfalls Reference

## execute_code sandbox curly-brace parsing

When running `hermes kanban comment` via `subprocess.run()` inside `execute_code`, the Python sandbox parses the entire script as Python before executing. Curly braces in comment bodies are interpreted as Python dict/set literals:

```python
# This FAILS inside execute_code:
subprocess.run(['hermes', 'kanban', 'comment', task_id,
  'Return value: {private_key_cipher, iv, tag}'])
# NameError: name 'private_key_cipher' is not defined
```

**Mitigation strategies (in order of preference):**

1. **Use `terminal()` instead** -- the terminal tool passes strings directly to the shell without Python parsing. Best for long/complex comment bodies.

2. **Remove curly braces** -- rewrite technical descriptions without JSON-like syntax:
   - Bad: `returns {cipher, iv, tag}`
   - Good: `returns cipher/iv/tag three fields`

3. **Use separate file for long bodies** -- write comment text to a temp file, then pass via shell redirection.

## kanban comment body length

Very long comment bodies (>500 chars) may fail silently or truncate. Keep individual comments concise and split complex instructions across multiple comments if needed.

## kanban create body length vs comment

When task descriptions are long (>300 chars), prefer:
1. Short title in `hermes kanban create`
2. Add detail via `hermes kanban comment <id> '...'`
This avoids shell argument parsing issues with the `create` command.
