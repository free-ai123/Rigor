---
name: kanban-orchestrator
description: Decomposition playbook + anti-temptation rules for an orchestrator profile routing work through Kanban.
version: 3.2.0
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [kanban, multi-agent, orchestration, routing]
    related_skills: [kanban-worker, nodejs-collector-pattern]
---

# Kanban Orchestrator — Decomposition Playbook

> The **core worker lifecycle** (including the `kanban_create` fan-out pattern and the "decompose, don't execute" rule) is auto-injected into every kanban process via the `KANBAN_GUIDANCE` system-prompt block. This skill is the deeper playbook when you're an orchestrator profile whose whole job is routing.

## Profiles are user-configured — not a fixed roster

Hermes setups vary widely. Before fanning out, discover available profiles via `hermes profile list` or `kanban_list(assignee="<name>")`. The dispatcher silently fails to spawn unknown assignee names.

## The anti-temptation rules

- **Do not execute the work yourself.** Create tasks for the right specialist.
- **Split multi-lane requests before creating cards.**
- **Run independent lanes in parallel.**
- **Never create dependent work as independent ready cards.** Use `parents=[...]`.
- **If no specialist fits, ask the user which profile to create.**

## Pre-decomposition checklist (MANDATORY)

```
□ PRD 先行 — Is product-manager assigned to produce PRD first?
□ 并行最大化 — Are independent lanes truly independent?
□ DAG 无环 — Do dependencies form a directed acyclic graph?
□ 单一职责 — Each task assigned to exactly ONE profile?
□ 验收闭环 — Is there a product-manager UAT task at the end?
□ DS 按需 — data-scientist assigned ONLY for data analysis/ML/stats?
```

## Standard decomposition templates

### New feature development
```
T0: product-manager → PRD (independent)
    ↓
T1: code-reviewer → architecture review (depends T0)
T2: security-auditor → security design review (depends T0, parallel T1)
    ↓
T3: backend-engineer → DB & API definition (depends T0, T1, T2)
T3.5: product-manager → API design confirmation (depends T3)
T4: frontend-engineer → UI prototype (depends T0, T1)
    ↓
T5: backend-engineer → API implementation (depends T3.5)
T6: frontend-engineer → frontend implementation (depends T4, T5)
    ↓
T7: code-reviewer → code review (depends T5, T6)
    ↓
    ├── T8: qa-engineer → testing (depends T7)
    ├── T9: security-auditor → security audit (depends T7, parallel T8)
    └── T10: devops-engineer → deploy prep (depends T7, parallel T8/T9)
         ↓ (wait for T8, T9, T10 ALL pass)
    T11: devops-engineer → deployment (depends T8, T9, T10)
    ↓
T12: product-manager → UAT (depends T11)
```

## Critical Pitfalls

**Worker modifies spec/schema and drifts from original design.** Workers (especially backend-engineer) may modify database schemas, field names, or API contracts from what the user originally specified. Example: T3 created `wallet_key` with fields `key_name`, `encrypted_key`, `iv` instead of the spec's `chain`, `address`, `private_key_cipher`, `private_key_iv`. This causes cascading failures in downstream code. **Detection**: When a task completes, verify the actual database structure against the spec using `DESCRIBE table_name`. **Fix**: If drift is detected, DROP and recreate the table with the correct schema before downstream tasks depend on it. Never assume workers faithfully reproduced the spec.

**Worker modifies code exports and function interfaces (not just DB schemas).** Beyond schema drift, workers also change function names, module exports, and constant values. From session evidence: `crypto.js` exported `encrypt`/`decrypt` instead of `encryptPrivateKey`/`decryptPrivateKey`; `amount.js` had `toWei`/`fromWei` but other code expected `toRaw`/`fromRaw` aliases; `db/collectorDb.js` lacked `initCollectorPool`/`getCollectorPool` methods; `constants/status.js` had values 1-5 when DB expected 0-8. **Detection**: After code tasks complete, run `node -e "require('./module'); console.log('OK')"` on each module and check `Object.keys(require('./module'))` to verify expected exports exist. Run a quick integration test loading the full dependency chain. **Fix**: Rewrite the mismatched modules to match the interface that other code expects. Verify with `node scripts/test_all.js` or equivalent integration test before marking tasks done.

**Worker changes constants/enum values silently.** Workers may redefine status constants, state enums, or configuration values to what they think is "better" without checking that other parts of the codebase depend on the original values. Example: `constants/status.js` was rewritten with `TASK_STATUS.PENDING=1` through `CANCELLED=5` when the database schema and all job files expected `0=待处理` through `8=跳过`. **Detection**: Grep for hardcoded status numbers across the codebase and compare against the constants file. If job files use `status IN (0, 3)` but constants define `PENDING=1`, there's a mismatch. **Fix**: Restore constants to match the database schema, not the worker's re-interpretation.

**Workers stuck in scratch GC loops due to terminal blocks.** When a worker's terminal access is blocked by security scanner, the worker enters a retry loop: reads existing files → tries to run `npm install` or verify DB → terminal denied → re-plans → repeats. It never writes files because it's stuck waiting for terminal approval. Symptom: task stays `running` for 10+ minutes, log shows repeated "preparing terminal…" then "denied" or "Timeout — denying command". **Detection**: Check `hermes kanban log <task_id>` — if you see repeated terminal blocks with no write_file operations, the worker is stuck. **Fix**: (1) Unblock the task with `hermes kanban unblock <id>`. (2) If unblocking doesn't help (worker is in a deep loop reading files repeatedly), manually complete with `hermes kanban complete <id> --summary "..."`. (3) Write the needed files yourself to the persistent project directory. **Note**: This is different from the scratch GC loop where the worker writes files and they get deleted — here the worker never writes at all because it can't run terminal commands.

**MySQL root password changed by worker.** A devops-engineer or backend-engineer task running MySQL commands may reset the root password as part of its work. After such a task completes, the original password may no longer work. **Detection**: `mysql -uroot -p<known_password> -e 'SELECT 1'` returns "Access denied" after a devops task. **Fix**: Use `skip-grant-tables` mode to reset: `kill mysqld`, restart with `mysqld --skip-grant-tables --user=mysql`, run `mysql -uroot -e "FLUSH PRIVILEGES; ALTER USER 'root'@'localhost' IDENTIFIED BY '<password>'; FLUSH PRIVILEGES;"`, then restart normally.

**`hermes kanban complete` rejects tasks in unknown state.** If a task is `running` (not `blocked` or `done`), `hermes kanban complete` may reject with "cannot complete (unknown id or terminal state)". **Fix**: First unblock with `hermes kanban unblock <id>`, then complete. If still rejected, the task may have already been completed by the worker — verify with `hermes kanban list`.

**Project files scattered across scratch workspaces.** Each worker writes to its own scratch workspace (`~/.hermes/kanban/workspaces/t_xxxx/`). If the orchestrator doesn't copy files to a persistent project directory, downstream workers and the final T_Final task will find nothing. **Fix**: After each worker completes, copy its output to `~/projects/<project-name>/`. For DB workers, copy SQL files; for backend workers, copy JS files; for devops workers, copy config files.

**CLI `--parent` only accepts ONE parent per call.** Use `hermes kanban create "..." --parent id1` then `hermes kanban link id2 child_id` for multiple parents.

## Gateway prerequisites

The dispatcher lives inside the gateway process. Without a running gateway, tasks sit in `ready` forever. Check with `hermes gateway status`; start with `hermes gateway run &` or `hermes gateway start`.

## Post-completion verification checklist

After each code-producing task completes (backend-engineer, frontend-engineer, devops-engineer), run these checks before dispatching downstream tasks:

1. **Module load test**: `node -e "require('./module'); console.log('OK')"` for each new module
2. **Export verification**: `node -e "console.log(Object.keys(require('./module')))"` — check expected functions exist
3. **Database schema check**: `DESCRIBE table_name` — verify columns match the original spec
4. **Integration test**: Load the full dependency chain (`config → db → services → jobs`) to catch mismatched imports early

If any check fails, fix the issue yourself rather than waiting for the code-reviewer task — early detection saves 10+ minutes of wasted downstream work.

## User Preferences (QPON team)

- **Analysis before action**: When presented with optimization proposals, expects detailed item-by-item assessment tables (verdict, current state, rationale) before execution.
- **Communication**: Structured, tabular, conclusion-first. No verbose explanations unless asked.
- **Project handover**: Must list final path (`~/projects/<name>/`, not Kanban IDs), deployment URLs, and technical compromises.
- **Proactive tracking**: Wants orchestrator to track task progress and handle issues without being asked.
- **Code comments**: All production code must use Chinese JSDoc comments with `@module`, `@param`, `@returns`, and `@throws` annotations.

## Project archiving

After UAT passes, create a T_Final task:
```
T_Final: devops-engineer → Archive to ~/projects/<name>/, git init, README.md
```
